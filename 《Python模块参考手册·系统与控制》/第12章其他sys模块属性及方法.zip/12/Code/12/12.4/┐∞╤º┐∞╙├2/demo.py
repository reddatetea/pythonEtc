import sys
print(sys.float_info.max)