import sys
print(sys._getframe(0))