import sys
print(sys.int_info)