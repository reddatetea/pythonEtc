import sys
bits,size=sys.int_info # 使用两个变量存储位数所占的位数和字节大小
print('数字所占的位数：%d'%bits)
print('数字类型的字节大小：%d'%size)