import sys
print(sys.intern('hello'))