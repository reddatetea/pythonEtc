import sys
print(sys.maxsize)