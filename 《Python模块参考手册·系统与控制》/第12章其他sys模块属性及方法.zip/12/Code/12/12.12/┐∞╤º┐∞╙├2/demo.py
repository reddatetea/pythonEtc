python -X x=1 -X y=1
>>> import sys
>>> sys._xoptions