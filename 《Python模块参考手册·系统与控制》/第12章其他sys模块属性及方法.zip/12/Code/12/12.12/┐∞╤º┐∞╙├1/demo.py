python -X test
>>> import sys
>>> sys._xoptions