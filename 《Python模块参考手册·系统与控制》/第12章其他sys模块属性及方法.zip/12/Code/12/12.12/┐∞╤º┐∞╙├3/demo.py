python -X C:\Windows\System32\mspaint.exe
>>> import sys
>>> sys._xoptions