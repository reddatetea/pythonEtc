import sys
sys._clear_type_cache()