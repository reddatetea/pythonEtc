import sys
print(sys.__breakpointhook__)