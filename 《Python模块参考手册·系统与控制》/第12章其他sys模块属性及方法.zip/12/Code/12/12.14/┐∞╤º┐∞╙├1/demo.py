import sys
print(sys.__excepthook__)