import sys
print(sys.float_repr_style)