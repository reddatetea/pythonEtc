import sys
print(sys.modules["os"]) # 获取os模块的来源