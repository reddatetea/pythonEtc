import os  # 文件与操作系统相关模块
print('当前系统的原生环境类型是否为字节型：',os.supports_bytes_environ)
