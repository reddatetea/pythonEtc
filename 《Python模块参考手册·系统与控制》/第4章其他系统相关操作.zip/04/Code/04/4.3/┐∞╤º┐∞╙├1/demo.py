import os  # 文件与操作系统相关模块
print(os.urandom(10))  # 生成10个字节的随机数
print(os.urandom(10))  # 生成10个字节的随机数
print(os.urandom(10))  # 生成10个字节的随机数
