import sys
print(sys.__stderr__)