import sys
print(sys.__stdout__)