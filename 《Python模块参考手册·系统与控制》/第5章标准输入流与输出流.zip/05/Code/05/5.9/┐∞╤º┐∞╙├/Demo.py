import sys
print(sys.__stdin__)