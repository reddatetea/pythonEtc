import sys
print('请输入字符串：') # 提示用户输入字符串
str1 = sys.stdin.readline() # 记录用户输入
str2 = input()
print('str1长度：'+str(len(str1))) # 输出字符串长度
print('str2长度：'+str(len(str2))) # 输出字符串长度