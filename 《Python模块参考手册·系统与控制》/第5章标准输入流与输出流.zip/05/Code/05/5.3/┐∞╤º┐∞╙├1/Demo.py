import sys
print('请输入中文：') # 提示用户输入字符串
str = sys.stdin.readline() # 记录用户输入
print(str) # 输出字符串

print('请输入数字：') # 提示用户输入数字
str = sys.stdin.readline() # 记录用户输入
print(str) # 输出数字

print('请输入英文：') # 提示用户输入字母
str = sys.stdin.readline() # 记录用户输入
print(str) # 输出字母

print('请输入由中文、数字混合而成的字符串：') # 提示用户输入混合字符串
str = sys.stdin.readline() # 记录用户输入
print(str) # 输出混合字符串