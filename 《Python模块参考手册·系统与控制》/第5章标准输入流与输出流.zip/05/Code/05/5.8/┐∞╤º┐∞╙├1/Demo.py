import sys
sys.stderr.write('错误提示\n')
sys.stdout.write('正确信息')