import sys
sys.tracebacklimit=100 # 设置最大递归（回溯）层级为100级
print(sys.tracebacklimit) # 输出递归（回溯）层级