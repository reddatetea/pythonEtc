import sys
print(sys.getfilesystemencodeerrors())