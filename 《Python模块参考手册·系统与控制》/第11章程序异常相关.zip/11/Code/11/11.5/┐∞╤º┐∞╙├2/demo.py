python -W warning1,warning2,warning3
>>> import sys
>>> sys.warnoptions