python -W warning
>>> import sys
>>> sys.warnoptions