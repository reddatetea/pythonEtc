import os  # 文件与操作系统相关模块
print(os.getlogin( ))  # 获取当前系统的登录用户名
