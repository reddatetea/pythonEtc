import os  # 文件与操作系统相关模块
print(os.get_terminal_size())  # 输出终端大小
