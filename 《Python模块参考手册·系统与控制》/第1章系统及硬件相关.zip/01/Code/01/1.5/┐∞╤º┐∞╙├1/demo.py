import os  # 文件与操作系统相关模块
print(os.name)   # 获取当前操作系统对应的模块名称
