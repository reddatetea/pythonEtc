import os  # 文件与操作系统相关模块
print(os.cpu_count())  # 获取CPU的数量
