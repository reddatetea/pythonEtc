import os
os.system('"D:\\test\\变量.mp4"')
