import os  # 文件与操作系统相关模块
print(os.system(r'start e:/mot.txt'))  #打开文本文件
print(os.system(r'start e:/零基础学Python.pdf'))  #打开PDF文件
