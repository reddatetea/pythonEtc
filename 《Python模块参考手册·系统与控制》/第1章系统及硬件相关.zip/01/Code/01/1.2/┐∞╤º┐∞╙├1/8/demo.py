import os
os.system("taskmgr")
