import os
os.system("cleanmgr")
