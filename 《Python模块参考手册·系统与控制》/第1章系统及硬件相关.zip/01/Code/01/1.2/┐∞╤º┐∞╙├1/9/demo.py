import os
os.system("write")
