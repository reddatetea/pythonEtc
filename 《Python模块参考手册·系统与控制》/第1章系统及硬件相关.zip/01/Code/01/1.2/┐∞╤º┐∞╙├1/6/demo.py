import os
os.system("magnify")
