import os
os.system("sndvol")
