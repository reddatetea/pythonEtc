import os
os.system("osk")
