import os
os.system("diskmgmt")
