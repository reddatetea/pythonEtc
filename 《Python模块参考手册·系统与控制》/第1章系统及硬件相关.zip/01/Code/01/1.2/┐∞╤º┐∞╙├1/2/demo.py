import os
os.system("mspaint")
