import os
os.system("mstsc")
