import os
os.system("notepad")
