import os
os.system("shutdown -a") # 执行解除关机命令