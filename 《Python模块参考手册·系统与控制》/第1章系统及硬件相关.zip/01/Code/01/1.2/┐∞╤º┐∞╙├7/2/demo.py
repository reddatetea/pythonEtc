import os
time = "1000"  # 关闭倒计时，单位为秒
os.system("shutdown -s -t %s" % time) # 执行关机命令
