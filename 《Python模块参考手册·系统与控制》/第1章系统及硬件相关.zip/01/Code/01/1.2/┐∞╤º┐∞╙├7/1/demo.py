import os
os.system("shutdown -s") # 执行关机命令
