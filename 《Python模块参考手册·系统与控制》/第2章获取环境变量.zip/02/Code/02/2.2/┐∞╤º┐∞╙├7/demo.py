import os
print(os.environ['SYSTEMROOT'])   # 系统主目录
