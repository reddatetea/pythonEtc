import os
print(os.environ['LOGONSERVER']) # 机器名
