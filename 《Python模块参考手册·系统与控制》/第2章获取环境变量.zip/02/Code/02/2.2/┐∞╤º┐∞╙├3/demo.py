import os
os.environ['WORKON_HOME']="test" # 设置环境变量
print(os.getenv('WORKON_HOME')) # 获取环境变量方法
