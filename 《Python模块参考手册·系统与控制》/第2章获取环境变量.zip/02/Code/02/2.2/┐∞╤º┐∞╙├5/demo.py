import os
print(os.environ['TEMP'])        # 临时目录路径
