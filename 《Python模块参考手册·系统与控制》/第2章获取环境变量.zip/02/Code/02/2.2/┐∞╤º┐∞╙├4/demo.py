import os
print(os.environ['HOMEPATH'])    # 当前用户主目录
