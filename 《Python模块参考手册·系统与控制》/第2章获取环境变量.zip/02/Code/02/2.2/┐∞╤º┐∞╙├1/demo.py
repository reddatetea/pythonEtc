import os            # 文件与操作系统相关模块
print(os.environ)   # 获取当前操作系统的环境变量的映射对象
