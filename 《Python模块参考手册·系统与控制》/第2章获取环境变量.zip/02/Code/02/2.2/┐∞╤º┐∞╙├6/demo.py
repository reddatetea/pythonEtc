import os
print(os.environ['PATHEXT'])      # 可执行文件
