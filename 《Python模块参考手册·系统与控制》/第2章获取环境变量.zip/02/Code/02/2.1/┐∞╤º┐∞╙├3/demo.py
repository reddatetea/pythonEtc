import os                      # 文件与操作系统相关模块
data=os.getenv('PATH')         # 获取PATH环境变量的路径
print(data)                    # 输出路径
