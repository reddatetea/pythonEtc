import os
print(os. getenv('HOMEPATH'))    # 当前用户主目录
print(os.getenv('TEMP'))        # 临时目录路径
print(os. getenv('PATHEXT'))      # 可执行文件类型
print(os.getenv('SYSTEMROOT'))   # 系统主目录
print(os.getenv("programfiles"))  # 应用程序的默认安装目录
