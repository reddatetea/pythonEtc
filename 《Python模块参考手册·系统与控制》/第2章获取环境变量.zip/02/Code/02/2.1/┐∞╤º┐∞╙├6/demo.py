import os
print(os.getenv("OS"))  # 当前系统名称
