import os
print(os.getenv("USERNAME"))  # 当前Windows账户名
