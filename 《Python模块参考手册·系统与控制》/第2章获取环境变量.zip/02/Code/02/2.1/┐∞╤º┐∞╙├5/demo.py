import os
print(os.getenv('LOGONSERVER')) # 机器名
