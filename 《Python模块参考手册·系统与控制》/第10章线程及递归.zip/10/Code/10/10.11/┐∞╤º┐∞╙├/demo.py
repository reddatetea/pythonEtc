import sys
print('默认：',sys.get_coroutine_origin_tracking_depth())