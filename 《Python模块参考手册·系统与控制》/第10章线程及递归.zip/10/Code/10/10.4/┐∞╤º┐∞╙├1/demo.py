import sys
print(sys._current_frames())