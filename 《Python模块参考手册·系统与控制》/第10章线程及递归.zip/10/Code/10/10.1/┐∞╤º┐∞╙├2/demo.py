import sys
print('%.2f'%sys.getswitchinterval()) # 获取间隔并保留2位小数