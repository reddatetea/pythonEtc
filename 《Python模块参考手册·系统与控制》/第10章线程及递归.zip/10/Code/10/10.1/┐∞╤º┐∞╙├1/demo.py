import sys
print(sys.getswitchinterval()) # 输出默认线程间隔