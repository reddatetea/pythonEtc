import sys
print(sys.thread_info)