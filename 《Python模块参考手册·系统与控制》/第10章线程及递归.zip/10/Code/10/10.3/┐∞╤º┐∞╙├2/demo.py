import sys
list =sys.thread_info # 获取线程信息
for value in list: # 遍历列表
    print(value) # 输出