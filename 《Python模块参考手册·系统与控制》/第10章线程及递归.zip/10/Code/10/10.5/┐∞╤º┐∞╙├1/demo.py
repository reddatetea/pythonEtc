import sys
print('默认递归次数：',sys.getrecursionlimit()) # 输出默认递归深度