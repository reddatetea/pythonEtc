import sys
print(sys.get_asyncgen_hooks())