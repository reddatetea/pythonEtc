import sys
print(sys.getcheckinterval()) # 输出默认检查间隔