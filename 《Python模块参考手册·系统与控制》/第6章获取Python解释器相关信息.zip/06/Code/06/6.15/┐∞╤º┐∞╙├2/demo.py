import sys
interval = sys.getcheckinterval()
print('interval = {:0.3f}'.format(interval))