import sys
print(sys.__interactivehook__)
print(sys.__interactivehook__())