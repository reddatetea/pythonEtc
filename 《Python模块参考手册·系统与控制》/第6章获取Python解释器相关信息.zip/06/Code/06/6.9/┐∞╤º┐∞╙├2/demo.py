python -d -i -O -I
>>> import sys
>>> sys.flags