python
>>> import sys
>>> sys.flags