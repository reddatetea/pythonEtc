import sys
print(sys.is_finalizing())