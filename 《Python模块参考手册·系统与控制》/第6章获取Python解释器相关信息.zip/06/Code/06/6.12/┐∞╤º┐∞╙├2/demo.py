>>> import sys
>>> sys.ps1='<<<'
<<<sys.ps1