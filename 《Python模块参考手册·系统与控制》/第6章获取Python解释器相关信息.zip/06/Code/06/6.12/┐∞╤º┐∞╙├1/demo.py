>>> import sys
>>> sys.ps1