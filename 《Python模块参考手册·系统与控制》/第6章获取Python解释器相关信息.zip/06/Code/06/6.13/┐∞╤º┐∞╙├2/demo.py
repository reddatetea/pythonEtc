>>> import sys
>>> sys.ps2='***'
>>> sys.ps2