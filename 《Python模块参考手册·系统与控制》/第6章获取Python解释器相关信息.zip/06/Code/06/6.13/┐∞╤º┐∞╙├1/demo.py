>>> import sys
>>> sys.ps2