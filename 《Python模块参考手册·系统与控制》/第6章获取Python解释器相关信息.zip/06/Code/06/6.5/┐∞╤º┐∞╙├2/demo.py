import sys
hexversion = hex(sys.hexversion) #Python版本号的十六进制表示形式
print(hexversion)