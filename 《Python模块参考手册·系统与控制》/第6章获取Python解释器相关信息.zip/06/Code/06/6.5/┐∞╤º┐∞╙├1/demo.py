import sys
print(sys.hexversion)