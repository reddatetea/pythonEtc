import sys
if sys.hexversion == 0x30701F0:
    print('您当前使用的是Python 3.7.1版本')
else:
    print('您当前使用的不是Python 3.7.1版本')