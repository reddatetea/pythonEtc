import sys
print('Before exit()')
sys.exit(10)
print('After exit()')#该行不会输出