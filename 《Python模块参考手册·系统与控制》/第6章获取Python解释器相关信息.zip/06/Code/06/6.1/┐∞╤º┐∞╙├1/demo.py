import sys
print(sys.version_info)