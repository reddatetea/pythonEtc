import sys
print(sys.argv)
print(sys.argv[0])