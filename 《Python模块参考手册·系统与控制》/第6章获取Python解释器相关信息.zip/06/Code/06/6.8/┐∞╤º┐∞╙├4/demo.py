import sys
print('参数个数:', len(sys.argv), '个参数')
print('参数列表:', str(sys.argv))