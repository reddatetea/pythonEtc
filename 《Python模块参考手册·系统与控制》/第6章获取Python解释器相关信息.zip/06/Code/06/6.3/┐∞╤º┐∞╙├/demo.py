import sys
print(sys.api_version)