import sys
print(sys.getdefaultencoding())

