import sys
print(sys.byteorder)

