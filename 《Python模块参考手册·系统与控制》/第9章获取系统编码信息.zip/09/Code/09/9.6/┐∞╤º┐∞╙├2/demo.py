#encoding=utf-8
import sys
sys.dont_write_bytecode = True
print(sys.dont_write_bytecode)



