import sys
print(sys.dont_write_bytecode)

