python –B .py文件     #  单次不出现

PYTHONDONTWRITEBYTECODE=1   #  永久不出现