import sys
print(sys.maxunicode)

