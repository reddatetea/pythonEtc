import sys
print(sys.hash_info.nan)



