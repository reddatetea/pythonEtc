#encoding=utf-8
import sys
print(sys.hash_info.seed_bits)





