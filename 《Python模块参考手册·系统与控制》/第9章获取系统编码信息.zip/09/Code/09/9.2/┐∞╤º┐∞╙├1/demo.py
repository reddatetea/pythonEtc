import sys
print(sys.getfilesystemencoding())

