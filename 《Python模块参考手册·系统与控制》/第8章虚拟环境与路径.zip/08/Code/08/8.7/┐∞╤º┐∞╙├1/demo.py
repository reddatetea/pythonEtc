import sys
print(sys.meta_path)
