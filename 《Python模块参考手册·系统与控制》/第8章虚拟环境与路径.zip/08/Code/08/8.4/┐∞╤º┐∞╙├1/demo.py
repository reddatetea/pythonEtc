import sys
print(sys.base_prefix)
