import sys
print(sys.prefix)
