import sys
print(sys.base_exec_prefix)
