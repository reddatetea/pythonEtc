#encoding=utf-8
import sys
sys.path.append("./module") # 添加模块搜索路径
for i in sys.path:  # 遍历所有路径列表
    print(i) # 输出遍历到的路径
