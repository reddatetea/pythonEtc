#encoding=utf-8
import sys

for i in sys.path:  # 遍历所有路径列表
    print(i)  # 输出遍历到的路径
