#encoding=utf-8
import sys
print("当前Python文件的路径为：", sys.path[0])
