import sys
print(sys.path_hooks)
