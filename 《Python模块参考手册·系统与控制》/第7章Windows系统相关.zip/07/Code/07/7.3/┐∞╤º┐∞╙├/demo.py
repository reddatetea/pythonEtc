import sys
print(sys.winver)