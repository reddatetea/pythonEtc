import sys
print(sys._debugmallocstats())