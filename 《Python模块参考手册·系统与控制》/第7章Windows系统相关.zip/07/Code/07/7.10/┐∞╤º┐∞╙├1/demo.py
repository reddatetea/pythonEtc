import sys
print(sys.path_importer_cache)