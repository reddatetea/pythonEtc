import sys
if sys.platform=='win32':
    print('当前是Windows平台')
if sys.platform=='linux':
    print('当前是Linux平台')
if sys.platform=='darwin':
    print('当前是MacOS平台')
