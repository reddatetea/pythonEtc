import sys
print(sys.getallocatedblocks())