import sys
print(sys.dllhandle)