import os  # 文件与操作系统相关模块
times = os.times()  # 返回当前的全局进程时间
print(times) # 返回当前的全局进程时间
