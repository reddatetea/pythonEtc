import os  # 文件与操作系统相关模块
print('重新启动前')
os._exit(1) # 重新启动Python Shell
print('重新启动后')
