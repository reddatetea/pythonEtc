import os  # 文件与操作系统相关模块
os.kill(os.getpid(),9)  # 杀死当前进程
