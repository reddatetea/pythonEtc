import os  # 文件与操作系统相关模块
os.abort() # 发送一个程序请求异常终止信号
