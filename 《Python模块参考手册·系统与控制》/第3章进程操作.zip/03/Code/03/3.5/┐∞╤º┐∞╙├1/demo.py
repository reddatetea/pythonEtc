import os  # 文件与操作系统相关模块
print(os.getppid( ))  # 获取父进程ID
