import os  # 文件与操作系统相关模块
print(os.getpid())  # 获取当前进程ID
